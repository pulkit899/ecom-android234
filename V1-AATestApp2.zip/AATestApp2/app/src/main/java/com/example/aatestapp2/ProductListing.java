package com.example.aatestapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageButton;

import com.adobe.marketing.mobile.MobileCore;

import java.util.HashMap;

public class ProductListing extends AppCompatActivity
{
    HashMap<String, String> contextData = new HashMap<String,String>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_listing);


        final ImageButton buyButton = (ImageButton) findViewById(R.id.imageButton);
        final ImageButton buyButton2 = (ImageButton) findViewById(R.id.imageButton4);
        final ImageView oneplus = (ImageView) findViewById(R.id.oneplus);
        final ImageView poco_c50 = (ImageView) findViewById(R.id.poco_c50);

        Intent goToCart =  new Intent(getApplicationContext(), cart.class);
        Intent goToProduct =  new Intent(getApplicationContext(), product_details.class);

        oneplus.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                String productPrice = getString(R.string.oneplus_price);
                String productString = "Mobile Devices;"+getString(R.string.Phone_2)+";1;"+productPrice+";;";

                contextData.clear();
                contextData.put("&&products", productString);
                MobileCore.trackAction("Product Image Click", contextData);

                goToProduct.putExtra("productName", getString(R.string.Phone_2));
                goToProduct.putExtra("productString", productString);
                goToProduct.putExtra("productPrice", productPrice);
                goToProduct.putExtra("quantity", "1");
                startActivity(goToProduct);
            }
        });

        poco_c50.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                String productPrice = getString(R.string.poco_price);
                String productString = "Mobile Devices;"+getString(R.string.Phone_1)+";1;"+productPrice+";;";

                contextData.clear();
                contextData.put("&&products", productString);
                MobileCore.trackAction("Product Image Click", contextData);

                goToProduct.putExtra("productName", getString(R.string.Phone_1));
                goToProduct.putExtra("productString", productString);
                goToProduct.putExtra("productPrice", productPrice);
                goToProduct.putExtra("quantity", "1");
                startActivity(goToProduct);
            }
        });

        buyButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {

                String productPrice = getString(R.string.oneplus_price);
                String productString = "Mobile Devices;"+getString(R.string.Phone_2)+";1;"+productPrice+";;";

                contextData.clear();
                contextData.put("d.prodEvents", "scAdd");
                contextData.put("&&products", productString);
                MobileCore.trackAction("Buy now button click", contextData);

                goToCart.putExtra("productName", getString(R.string.Phone_2));
                goToCart.putExtra("productString", productString);
                goToCart.putExtra("productPrice", productPrice);
                goToCart.putExtra("quantity", "1");
                goToCart.putExtra("buyType", "now");
                startActivity(goToCart);
            }
        });

        buyButton2.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                String productPrice = getString(R.string.poco_price);
                String productString = "Mobile Devices;"+getString(R.string.Phone_1)+";1;"+productPrice+";;";

                contextData.clear();
                contextData.put("d.prodEvents", "scAdd");
                contextData.put("&&products", productString);
                MobileCore.trackAction("Buy now button click", contextData);

                goToCart.putExtra("productName", getString(R.string.Phone_1));
                goToCart.putExtra("productString", productString);
                goToCart.putExtra("productPrice", productPrice);
                goToCart.putExtra("quantity", "1");
                goToCart.putExtra("buyType", "now");
                startActivity(goToCart);
            }
        });
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        MobileCore.setApplication(getApplication());
        MobileCore.lifecycleStart(null);

        contextData.clear();
        contextData.put("&&products", "Mobile Devices;"+getString(R.string.Phone_2)+";;;;,"+"Mobile Devices;"+getString(R.string.Phone_1)+";;;;");
        contextData.put("d.prodEvents", "impression");
        contextData.put("d.page", getString(R.string.productlist));
        MobileCore.trackState(getString(R.string.productlist), contextData);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        MobileCore.lifecyclePause();
    }
}