package com.example.aatestapp2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.adobe.marketing.mobile.MobileCore;

import java.util.HashMap;

public class checkout_page_1 extends AppCompatActivity
{

    HashMap contextData = new HashMap<String,String>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_page1);

        Intent checkoutPage = getIntent();
        Intent goToConfirmation = new Intent(getApplicationContext(), confirmation.class);

        ImageView qImageView = (ImageView)findViewById(R.id.imageView3);
        TextView productName = (TextView)findViewById(R.id.textView2);
        TextView quantity =(TextView)findViewById(R.id.textView3);
        TextView price =(TextView)findViewById(R.id.textView4);
        Button order =(Button)findViewById(R.id.button2);

        if (checkoutPage.getStringExtra("productName").equals(getString(R.string.Phone_2)))
        {
            qImageView.setImageResource(R.drawable.oneplus_9);
        }
        else if (checkoutPage.getStringExtra("productName").equals(getString(R.string.Phone_1)))
        {
            qImageView.setImageResource(R.drawable.poco_c50);
        }

        productName.setText(checkoutPage.getStringExtra("productName"));
        quantity.setText("Quantity: "+checkoutPage.getStringExtra("quantity"));
        price.setText("Price: "+checkoutPage.getStringExtra("productPrice"));

        order.setOnClickListener(new View.OnClickListener()
        {

            @Override
            public void onClick(View v)
            {
                contextData.put("d.prodEvents", "purchase");
                contextData.put("&&products", checkoutPage.getStringExtra("productString"));
                MobileCore.trackAction("Place order button click", contextData);

                goToConfirmation.putExtra("productString", checkoutPage.getStringExtra("productString"));
                startActivity(goToConfirmation);
            }
        });

    }

    @Override
    protected void onResume()
    {
        super.onResume();

        Intent checkoutPage = getIntent();
        MobileCore.setApplication(getApplication());
        MobileCore.lifecycleStart(null);

        contextData.clear();
        contextData.put("d.page", R.string.pagename_checkout);
        contextData.put("&&products", checkoutPage.getStringExtra("productString"));
        //contextData.put("d.manufacturer", Build.MANUFACTURER);
        MobileCore.trackState("Checkout", contextData);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        MobileCore.lifecyclePause();
    }
}