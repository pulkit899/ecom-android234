package com.example.aatestapp2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.adobe.marketing.mobile.MobileCore;
import java.util.HashMap;

public class SecondActivity extends AppCompatActivity
{

    HashMap contextData = new HashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        MobileCore.lifecycleStart(null);
        contextData.put("d.page", getString(R.string.successful_Page));
        MobileCore.trackState("Screen 2", contextData);
    }
}