package com.example.ecom_android;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.adobe.marketing.mobile.MobileCore;

import java.util.HashMap;

public class cart extends AppCompatActivity
{
    HashMap contextData = new HashMap<String,String>();
    //public Intent cartPage = getIntent();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        Intent cartPage = getIntent();
        Intent goToCheckout = new Intent(getApplicationContext(), checkout_page_1.class);

        ImageView qImageView = (ImageView)findViewById(R.id.imageView3);
        TextView productName = (TextView)findViewById(R.id.textView2);
        TextView quantity =(TextView)findViewById(R.id.textView3);
        Button checkOut =(Button)findViewById(R.id.button2);

        productName.setText(cartPage.getStringExtra("productName"));
        quantity.setText("Quantity: "+cartPage.getStringExtra("quantity"));

        if(cartPage.getStringExtra("buyType").equals("now"))
        {

            if (cartPage.getStringExtra("productName").equals(getString(R.string.Phone_2)))
                qImageView.setImageResource(R.drawable.oneplus_9);


            if (cartPage.getStringExtra("productName").equals(getString(R.string.Phone_1)))
                qImageView.setImageResource(R.drawable.poco_c50);

            checkOut.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {

                    contextData.clear();
                    contextData.put("d.prodEvents", "scCheckout");
                    contextData.put("&&products", cartPage.getStringExtra("productString"));
                    MobileCore.trackAction("Checkout button click", contextData);

                    goToCheckout.putExtra("productName", cartPage.getStringExtra("productName"));
                    goToCheckout.putExtra("quantity", cartPage.getStringExtra("quantity"));
                    goToCheckout.putExtra("productPrice", cartPage.getStringExtra("productPrice"));
                    goToCheckout.putExtra("productString", cartPage.getStringExtra("productString"));
                    startActivity(goToCheckout);
                }
            });
        }
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        Intent cartPage = getIntent();
        MobileCore.setApplication(getApplication());
        MobileCore.lifecycleStart(null);

        contextData.clear();
        contextData.put("d.page", R.string.pagename_cart);
        contextData.put("d.prodEvents", "scView");
        contextData.put("&&products", cartPage.getStringExtra("product"));
        //contextData.put("d.manufacturer", Build.MANUFACTURER);
        MobileCore.trackState(getString(R.string.pagename_cart), contextData);
    }

    @Override
    public void onPause()
    {
        super.onPause();
        MobileCore.lifecyclePause();
    }
}