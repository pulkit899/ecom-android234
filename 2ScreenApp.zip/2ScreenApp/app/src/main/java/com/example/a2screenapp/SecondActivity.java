package com.example.a2screenapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.adobe.marketing.mobile.MobileCore;

import java.util.HashMap;

public class SecondActivity extends AppCompatActivity
{

    HashMap contextdata = new HashMap<String, String>();

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        MobileCore.setApplication(getApplication());
        MobileCore.lifecycleStart(null);

        MobileCore.trackState("Screen 2", contextdata);
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        MobileCore.lifecyclePause();
    }
}
